*Copy and past all files in a new project, it should be ok.

*You will need to install qrencode to generate QR codes with the script, just tap : "sudo apt-get install qrencode" in a terminal.
