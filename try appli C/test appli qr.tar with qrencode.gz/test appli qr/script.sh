#!/bin/bash
qrencode $1 -o $2
echo "QRcode genere"